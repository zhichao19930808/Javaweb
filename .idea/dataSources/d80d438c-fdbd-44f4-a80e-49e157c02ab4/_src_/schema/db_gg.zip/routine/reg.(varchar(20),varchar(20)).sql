CREATE PROCEDURE db_gg.reg(IN uname VARCHAR(20), IN upassword VARCHAR(20), OUT message CHAR(10))
  BEGIN
declare i int default -1;
select count(1) into i from db_gg.account where name = uname;
if i>0 then
set message = '账户已存在';
else
insert into db_gg.account(name,password)values(uname,upassword);
set message = '注册成功';
end if;

END;
